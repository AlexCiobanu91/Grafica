#pragma once
class Environment
{

private:
	float _levelDistance;
	float _minPositionX;
	float _maxPositionX;
	float _lastPositionZ;
public:
	Environment(void);
	~Environment(void);
	Environment(float levelDistance, float minPositionX, float maxPositionX);

	float getMinPositionX();
	float getMaxPositionX();
	void createBloc();
	void renderEnvironment(float startZ);
	void linieIntrerupta();
	void genLinieIntrerupta(float positionX);
	void createPavement();
	void createARoad();
	void renderRoads(int nrRoads);
};

